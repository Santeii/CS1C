/*************************************************************************
 * AUTHOR		: Ryan Martinez
 * STUDENT ID	: 389657
 * Assignment	: 14
 * CLASS		: CS1C
 * SECTION		: MTWTH: 4PM
 * DUE DATE		: 7/21/2016
 ************************************************************************/

	#include "header.h"

/*************************************************************************
 * Assignment 14
 * _______________________________________________________________________
 * This program displays different buffer overrun coding errors, both the
 * wrong way to go about coding, as well as the right way. This code shows
 * Static Buffer Overruns, Heap Overruns, and Boundary Checking Errors.
 * _______________________________________________________________________
 *
 ************************************************************************/


	int main()
	{
	//---------------------------------------------------------------------

	int menu;
	char inputName[50];
	char outputName[11];
	char* charArray;
	int* numberOfCells;
	int intArray[3];
	int index;

	//---------------------------------------------------------------------

	ClassHeader();

	cout << "Pick from the menu:\n"
		 << "1 - Static Buffer Overruns\n"
		 << "2 - Heap Overruns\n"
		 << "3 - Boundary Checking Errors\n"
		 << "0 - Exit\n";
	cin >> menu;


	while(menu != 0)
	{
		switch(menu)
		{
		case 1: 	// Static Buffer Overruns

					cout << "\nBAD\n";

					cout << "Enter ten characters for a name: \n";
					cin >> inputName;
					strcpy(outputName,inputName);
					cout << outputName << endl << endl;

					cout << "\nGOOD\n";

					cout << "Enter ten characters for a name: \n";
					cin >> inputName;
					strncpy(outputName,inputName,10);
					outputName[10] = '\0';
					cout << outputName;

		break;

		case 2:		// Heap Overruns

					cout << "\nBAD\n";

					cout << "An array will be created dynamically" << endl;
					numberOfCells = new int;
					cout << "Please enter number larger than 15 " << endl;
					cin >> *numberOfCells;
					charArray = new char[*numberOfCells];
					strcpy (charArray, "This is a test");
					cout << "Number of memory locations allocated was " << *numberOfCells << endl;
					cout << charArray << endl;
					delete numberOfCells;
					delete [] charArray;
					cout << "Number of memory location allocated was " << *numberOfCells << endl;
					cout << charArray << endl;

					cout << "\nGOOD\n";

					cout << "An array will be created dynamically" << endl;
					numberOfCells = new int;
					cout << "Please enter number larger than 15 " << endl;
					cin >> *numberOfCells;
					charArray = new char[*numberOfCells];
					strcpy (charArray, "This is a test");
					cout << "Number of memory locations allocated was " << *numberOfCells << endl;
					cout << charArray << endl;
					delete numberOfCells;
					delete [] charArray;

					numberOfCells = NULL;
					charArray = NULL;

					if(numberOfCells == NULL && charArray == NULL)
					{
						cout << "The pointers are pointing to NULL";
					}
					else
					{
						cout << "Number of memory location allocated was " << *numberOfCells << endl;
						cout << charArray << endl;
					}

		break;

		case 3:		// Boundary Checking Errors
					cout << "\nBAD\n";

					for (index=0;index <= 3;index++)
					{
					cout << "Please enter an integer: ";
					cin >> intArray[index];
					cout << "The integer just entered was " << intArray[index] << endl; ;
					}


					cout << "\nGOOD\n";

					for (index=0;index < 3;index++)
					{
					cout << "Please enter an integer: ";
					cin >> intArray[index];
					cout << "The integer just entered was " << intArray[index] << endl; ;
					}
		break;
		}

		cout << "\n\nPick from the menu:\n"
			 << "1 - Static Buffer Overruns\n"
			 << "2 - Heap Overruns\n"
			 << "3 - Boundary Checking Errors\n"
			 << "0 - Exit\n";
		cin >> menu;
	}
	return 0;
	}


